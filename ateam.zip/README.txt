Course: cs400
Semester: Fall 2019
Project name: Social Network
Team Members:
1. Luke VandenHeuvel, 001, lvandenheuve@wisc.edu
2. Benjamin Haisting, 001, bhaisting@wisc.edu
3. Yatharth Bindal, 001, ybindal@wisc.edu
4. Kennedy Soehren, 001, ksoehren@wisc.edu
4. Robert Bourguignon, 001, bourguignon@wisc.edu



Which team members were on same xteam together?
Luke, Benjamin, and Yatharth were on xteam 45
Robert and Kennedy were on xteam 8

Notes for Grader:
For this milestone, we have created the basics when it comes to initial UI. Both perspective mode and general perspective mode work, and the program can take in .txt files as well. We've hardcoded some inputs in as well as a file input, the program will work with any correct file input and will change into perspective mode if prompted. The main bug is that button's layer over eachother, ie we haven't figured out how to change stages or clear certain details of a button press. You will need to rerun the program between button presses currently.